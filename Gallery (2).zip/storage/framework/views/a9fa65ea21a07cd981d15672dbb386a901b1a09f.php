<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'ArtGallery')); ?></title>

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/hover.css')); ?>" rel="stylesheet">
</head>
<body>
    <div id="app">

        <nav class="navbar navbar-expand-md navbar-light navbar-laravel fixed-top">
            <div class="container">
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item">
                        <a href="/info"><img class="navbar-brand" src="../storage/images/logo.jpg"></a>
                    </li>
                </ul>
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                    <?php echo e(__('messages.art_gallery')); ?>

                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>


                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav mr-auto">
                        <li class="nav-item">
                            <a class="nav-link btn btn-light mr-1" role="button" href="/artists"><?php echo e(__('messages.artists')); ?></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link btn btn-light mr-1" role="button" href="/events"><?php echo e(__('messages.events')); ?></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link btn btn-light mr-1" role="button" href="../management"><?php echo e(__('messages.management')); ?></a>
                        </li>

                        <?php if(Auth::check()): ?>
                        <?php if(Auth::user()->admin): ?>
                            <li class="nav-item">
                                <a class="nav-link btn btn-light mr-1" role="button" href="/activate"><?php echo e(__('messages.activate')); ?></a>
                            </li>
                        <?php endif; ?>
                            <?php endif; ?>
                        <li class="nav-item">
                            <a class="nav-link btn btn-light mr-1" role="button" href="../email"><?php echo e(__('messages.e-mail')); ?></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link btn btn-light mr-1" role="button" href="../map"><?php echo e(__('messages.be_our_guest')); ?></a>
                        </li>

                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <!-- Authentication Links -->
                        <li class="nav-item ">
                            <a type="button" role="button" class="nav-link btn btn-light btn-sm " href="/en">En</a>
                        </li>
                        <li class="nav-item ">
                            <a type="button" role="button" class="nav-link btn btn-light btn-sm " href="/ru">Ru</a>
                        </li>
                        <?php if(auth()->guard()->guest()): ?>
                            <li><a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('messages.login')); ?></a></li>
                            <li><a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('messages.register')); ?></a></li>
                        <?php else: ?>
                            <?php if(Auth::user()->activated): ?>
                            <li class="nav-item">
                                <a class="nav-link btn btn-light mr-1" role="button" href="../createDrawing"><?php echo e(__('messages.upload drawing')); ?></a>
                            </li>
                            <?php endif; ?>
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                                </a>

                                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('messages.logout')); ?>

                                    </a>
                                    <a class="dropdown-item" href="/userPage/<?php echo e(Auth::user()->id); ?>">
                                        <?php echo e(__('messages.myprofile')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>
        <main class="py-4 mt-md-5">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/myjs.js')); ?>"></script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCEp6PZ-wytWuFa9uPVqXgdzmQVCBHku34&callback=initMap"
            async defer>
    </script>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
</body>
</html>
