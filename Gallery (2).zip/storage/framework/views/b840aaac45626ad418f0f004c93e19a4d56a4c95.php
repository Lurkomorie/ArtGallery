<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="card-columns py-5 bg-light ml-4">
            <?php $__currentLoopData = $artists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $artist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(!$artist->deleted  && $artist->role!='artist'): ?>
                    <a href="userPage/<?php echo e($artist->id); ?>" style="text-decoration: none; color: black;">
                        <div class="card box-shadow ">
                            <img class="img-fluid rounded float-right mb-md-3" src="../<?php echo e($artist->avatar); ?>" alt="">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo e($artist->name); ?></h5>
                                <ul class="list-group list-group-flush">
                                    <li class="list-group-item"><?php echo e(__('messages.role')); ?>: <?php echo e($artist->role); ?></li>
                                    <li class="list-group-item"><?php echo e(__('messages.email')); ?>: <?php echo e($artist->email); ?></li>
                                    <li class="list-group-item"><?php echo e(__('messages.country')); ?>: <?php echo e($artist->country); ?></li>
                                    <li class="list-group-item"><?php echo e(__('messages.city')); ?>: <?php echo e($artist->city); ?></li>
                                    <li class="list-group-item">BIO: <?php echo e($artist->bio); ?></li>
                                </ul>
                            </div>
                        </div>


                    </a>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>