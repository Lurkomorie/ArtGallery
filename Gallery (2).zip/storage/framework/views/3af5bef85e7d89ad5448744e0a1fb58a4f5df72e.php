<?php $__env->startSection('content'); ?>

    <div class="container">

        <div class="card-columns py-5 bg-light ml-4">
            <h1>Sorted content</h1>
            <?php $__currentLoopData = $drawings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $drawing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(!$drawing->removed): ?>
                    <div class="card box-shadow">
                        <img class="card-img-top img-fluid" src="<?php echo e($drawing->picture); ?>">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($drawing->name); ?></h5>
                            <ul class="list-group list-group-flush">
                                <li class="list-group-item">Author: <?php echo e(\App\User::find($drawing->artistId)->name); ?></li>
                                <li class="list-group-item">Country: <?php echo e($drawing->country); ?></li>
                                <li class="list-group-item">City: <?php echo e($drawing->city); ?></li>
                                <li class="list-group-item">Genre: <?php echo e($drawing->genre); ?></li>
                                <li class="list-group-item">Technology: <?php echo e($drawing->technology); ?></li>
                                <li class="list-group-item">Size: <?php echo e($drawing->size); ?></li>
                            </ul>
                            <div class="card-footer">
                                <h3 class="card-title">Price: <?php echo e($drawing->price); ?>€</h3>
                                <small class="text-muted"><?php echo e($drawing->date); ?></small>
                            </div>
                            <div class="btn-group" role="group">
                                <button type="button" class="btn btn-secondary">View</button>
                                <?php if(Auth::check()): ?>
                                    <?php if(Auth::user()->id==$drawing->artistId|| Auth::user()->admin): ?>
                                        <a type="button" href="../../updateDrawing/<?php echo e($drawing->id); ?>"class="btn btn-secondary">Edit</a>
                                        <a type="button" href="../../removeDrawing/<?php echo e($drawing->id); ?>"class="btn btn-secondary">Delete</a>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>