<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header"><?php echo e(__('messages.update')); ?></div>

                    <div class="card-body">
                        <form method="POST" action="<?php echo e(route('update_user')); ?>">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" id="id" name="id" value="<?php echo e($artist->id); ?>">
                            <div class="form-group row">
                                <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('messages.name')); ?></label>

                                <div class="col-md-6">
                                    <input id="name" type="text" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e($artist->name); ?>" required autofocus>

                                    <?php if($errors->has('name')): ?>
                                        <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="city" class="col-md-4 col-form-label text-md-right"><?php echo e(__('messages.city')); ?></label>

                                <div class="col-md-6">
                                    <input id="city" type="text" class="form-control<?php echo e($errors->has('city') ? ' is-invalid' : ''); ?>" name="city" value="<?php echo e($artist->city); ?>" required>

                                    <?php if($errors->has('city')): ?>
                                        <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('city')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="country" class="col-md-4 col-form-label text-md-right"><?php echo e(__('messages.country')); ?></label>

                                <div class="col-md-6">
                                    <input id="country" type="text" class="form-control<?php echo e($errors->has('country') ? ' is-invalid' : ''); ?>" name="country" value="<?php echo e($artist->country); ?>" required>

                                    <?php if($errors->has('country')): ?>
                                        <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('country')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="bio" class="col-md-4 col-form-label text-md-right"><?php echo e(__('BIO')); ?></label>

                                <div class="col-md-6">
                                    <textarea id="bio" type="text" rows='3' class="form-control<?php echo e($errors->has('bio') ? ' is-invalid' : ''); ?>" name="bio" value="<?php echo e($artist->bio); ?>" required></textarea>

                                    <?php if($errors->has('bio')): ?>
                                        <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('bio')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row mb-0">
                                <div class="col-md-6 offset-md-4">
                                    <button type="submit" class="btn btn-primary">
                                        <?php echo e(__('messages.update')); ?>

                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>