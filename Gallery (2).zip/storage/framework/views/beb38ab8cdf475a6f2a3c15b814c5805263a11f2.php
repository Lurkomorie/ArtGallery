<?php $__env->startSection('content'); ?>

    <div class="container">
        <?php if(Auth::check()): ?>
        <?php if(Auth::user()->admin): ?>
            <a class="nav-link btn btn-light mr-1" role="button" href="/createEvent"><?php echo e(__('messages.add_event')); ?></a>
        <?php endif; ?>
        <?php endif; ?>
        <div class="card-columns py-5 bg-light ml-4">
            <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(!$event->removed): ?>
                <div class="card box-shadow">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($event->name); ?></h5>
                        <ul class="list-group list-group-flush">
                            <li class="list-group-item"><?php echo e(__('messages.country')); ?>: <?php echo e($event->country); ?></li>
                            <li class="list-group-item"><?php echo e(__('messages.city')); ?>: <?php echo e($event->city); ?></li>
                            <li class="list-group-item"><?php echo e(__('messages.date')); ?>: <?php echo e($event->date); ?></li>
                            <li class="list-group-item"><?php echo e(__('messages.description')); ?>: <?php echo e($event->description); ?></li>
                        </ul>
                    </div>
                    <?php if(Auth::check()): ?>
                        <?php if( Auth::user()->admin): ?>
                            <a type="button" href="../../updateEvent/<?php echo e($event->id); ?>"class="btn btn-secondary"><?php echo e(__('messages.edit')); ?></a>
                            <a type="button" href="../../removeEvent/<?php echo e($event->id); ?>"class="btn btn-secondary"><?php echo e(__('messages.delete')); ?></a>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>