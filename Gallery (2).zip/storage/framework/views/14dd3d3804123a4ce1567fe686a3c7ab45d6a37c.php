<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="jumbotron jumbotron-fluid row">
            <div class="col-md-7">
                <h2 class="display-3"><?php echo e(\App\User::find($artistId)->name); ?></h2>
                <p class="lead"><?php echo e(__('messages.city')); ?>: <?php echo e(\App\User::find($artistId)->city); ?></p>
                <p class="lead"><?php echo e(__('messages.country')); ?>: <?php echo e(\App\User::find($artistId)->country); ?></p>
                <p class="lead">Bio: <?php echo e(\App\User::find($artistId)->bio); ?></p>
                <?php if(\App\User::find($artistId)->role!='artist'): ?>
                    <p class="lead"><?php echo e(__('messages.role')); ?>: <?php echo e(\App\User::find($artistId)->role); ?></p>
                <?php endif; ?>
                <?php if(Auth::check()): ?>
                    <?php if(Auth::user()->id==\App\User::find($artistId)->id || Auth::user()->admin): ?>
                        <div class="mt-md-5">
                            <a type="button" href="../../updateUser/<?php echo e(\App\User::find($artistId)->id); ?>"class="btn btn-secondary"><?php echo e(__('messages.edit')); ?></a>
                            <a type="button" href="../../removeUser/<?php echo e(\App\User::find($artistId)->id); ?>"class="btn btn-secondary"><?php echo e(__('messages.delete')); ?></a>
                            <a type="button" href="../../addAvatar/<?php echo e(\App\User::find($artistId)->id); ?>"class="btn btn-secondary"><?php echo e(__('messages.add_avatar')); ?></a>
                            <?php if(Auth::user()->admin): ?>
                                <a type="button" href="../../setRole/<?php echo e(\App\User::find($artistId)->id); ?>"class="btn btn-secondary"><?php echo e(__('messages.set_role')); ?></a>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
            <div class="col-md-4 float-right">
                <img class="img-fluid rounded float-right" src="../<?php echo e(\App\User::find($artistId)->avatar); ?>" alt="">
            </div>
        </div>
        <div class="card-columns py-5 bg-light ml-4">
            <?php $__currentLoopData = \App\Drawing::where('artistId', $artistId)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $drawing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(!$drawing->removed): ?>
                    <a href="../img/<?php echo e($drawing->id); ?>" style="text-decoration: none; color: black;">
                <div class="card box-shadow">
                    <img class="card-img-top img-fluid" src="..\<?php echo e($drawing->picture); ?>">
                    <div class="card-body">
                        <h5 class="card-title text-lg-center"><?php echo e($drawing->title); ?></h5>
                        <ul class="list-group list-group-flush">
                            <li class="list-group-item"><?php echo e(__('messages.country')); ?>: <?php echo e($drawing->country); ?></li>
                            <li class="list-group-item"><?php echo e(__('messages.city')); ?>: <?php echo e($drawing->city); ?></li>
                            <li class="list-group-item"><?php echo e(__('messages.genre')); ?>: <?php echo e($drawing->genre); ?></li>
                            <li class="list-group-item"><?php echo e(__('messages.technology')); ?>: <?php echo e($drawing->technology); ?></li>
                            <li class="list-group-item"><?php echo e(__('messages.size')); ?>: <?php echo e($drawing->size); ?></li>
                        </ul>
                        <div class="card-footer">
                            <h3 class="card-title"><?php echo e(__('messages.price')); ?>: <?php echo e($drawing->price); ?>€</h3>
                            <small class="text-muted"><?php echo e($drawing->date); ?></small>
                        </div>
                        <div class="btn-group" role="group">
                            <?php if(Auth::check()): ?>
                            <?php if(Auth::user()->id==$artistId || Auth::user()->admin): ?>
                            <a type="button" href="../../updateUser/<?php echo e($drawing->id); ?>"class="btn btn-secondary"><?php echo e(__('messages.edit')); ?></a>
                            <a type="button" href="../../removeUser/<?php echo e($drawing->id); ?>"class="btn btn-secondary"><?php echo e(__('messages.delete')); ?></a>

                            <?php endif; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                    </a>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>