<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header"><?php echo e(__('messages.status')); ?></div>

                    <div class="card-body">
                            <div class="row">
                                <h2 class="col-md-6 mx-auto text-lg-center card-title"><?php echo e($message['text']); ?></h2>
                            </div>

                                <h3 class="col-md-4 mx-auto text-lg-center card-title"><?php echo e(__('messages.status')); ?>: <?php echo e($message['status']); ?></h3>

                            <div class="row">
                                <a href="/" class="col-md-4 mx-auto btn btn-dark"><?php echo e(__('messages.home_page')); ?></a>
                            </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>