<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row">
        <div class="card col-md-7">
        <img class="card-img-top img-fluid img-rounded" src="../<?php echo e($drawing->picture); ?>">
        </div>
        <div class="card col-md-4 ml-md-2">
            <h1 class="card-title text-lg-center mt-md-2"><?php echo e($drawing->title); ?></h1>
                <ul class="list-group list-group-flush">
                    <a href="../userPage/<?php echo e($drawing->artistId); ?>"><li class="list-group-item"><?php echo e(__('messages.author')); ?>: <?php echo e(\App\User::find($drawing->artistId)->name); ?></li></a>
                    <li class="list-group-item"><?php echo e(__('messages.country')); ?>: <?php echo e($drawing->country); ?></li>
                    <li class="list-group-item"><?php echo e(__('messages.city')); ?>: <?php echo e($drawing->city); ?></li>
                    <li class="list-group-item"><?php echo e(__('messages.genre')); ?>: <?php echo e($drawing->genre); ?></li>
                    <li class="list-group-item"><?php echo e(__('messages.technology')); ?>: <?php echo e($drawing->technology); ?></li>
                    <li class="list-group-item"><?php echo e(__('messages.size')); ?>: <?php echo e($drawing->size); ?></li>
                </ul>
            <div class="card-footer mt-md-5">
                <h3 class="card-title"><?php echo e(__('messages.price')); ?>: <?php echo e($drawing->price); ?>€</h3>
                <small class="text-muted"><?php echo e($drawing->date); ?></small>
            </div>
            <a class="btn btn-outline-success" href="../../email/<?php echo e($drawing->id); ?>"><?php echo e(__('messages.send_email_to_administrator')); ?></a>
            <?php if(Auth::check()): ?>
                <?php if(Auth::user()->id==$drawing->artistId|| Auth::user()->admin): ?>
                    <a type="button" href="../../updateDrawing/<?php echo e($drawing->id); ?>"class="btn btn-secondary"><?php echo e(__('messages.edit')); ?></a>
                    <a type="button" href="../../removeDrawing/<?php echo e($drawing->id); ?>"class="btn btn-secondary"><?php echo e(__('messages.delete')); ?></a>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>