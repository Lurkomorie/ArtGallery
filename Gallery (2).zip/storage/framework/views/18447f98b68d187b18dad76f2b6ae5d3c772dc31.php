<?php $__env->startSection('content'); ?>

    <div class="container">
        <nav class="navbar navbar-expand-md navbar-light navbar-laravel">
            <div class="container">
            <ul class="nav navbar-nav row">
                <li class="nav-item">
                    <button class="btn btn-link nav-link ml-md-3"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('title',__('messages.sortbytitle')));?></button>
                </li>
                <li class="nav-item">
                    <button class="btn btn-link nav-link ml-md-3"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('price',__('messages.sortbyprice')));?></button>
                </li>
                <li class="nav-item">
                    <button class="btn btn-link nav-link ml-md-3"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('created_at',__('messages.sortbynewness')));?></button>
                </li>
            </ul>
            <form class="form-inline pull-xs-right" action="<?php echo e(route('find_drawing')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <select id="column" name="column" class="form-group form-control mr-md-2">
                    <option value="title"><?php echo e(__('messages.title')); ?></option>
                    <option value="city"><?php echo e(__('messages.city')); ?></option>
                    <option value="country"><?php echo e(__('messages.country')); ?></option>
                    <option value="genre"><?php echo e(__('messages.genre')); ?></option>
                    <option value="technology"><?php echo e(__('messages.technology')); ?></option>
                    <option value="status"><?php echo e(__('messages.status')); ?></option>
                </select>

                <div class="form-group">
                <input id="search" type="text" class="form-control<?php echo e($errors->has('search') ? ' is-invalid' : ''); ?>" name="search" placeholder="<?php echo e(__('messages.search')); ?>" required autofocus>

                <?php if($errors->has('search')): ?>
                    <span class="invalid-feedback">
                                <strong><?php echo e($errors->first('search')); ?></strong>
                            </span>
                <?php endif; ?>
                </div>
                    <button type="submit" class="btn btn-outline-success ml-md-2">
                        <?php echo e(__('messages.search')); ?>

                    </button>
            </form>
            </div>
        </nav>
            <div class=" bg-light row">
            <?php $__currentLoopData = $drawings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $drawing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(!$drawing->removed): ?>
                <div class="mt-md-2 mb-md-2 col-md-4 hovereffect">
                    <img class="card-img-top img-fluid" src="<?php echo e($drawing->picture); ?>">
                    <div class="overlay">
                        <h1><a class="col-md-4" href="img/<?php echo e($drawing->id); ?>"><?php echo e($drawing->title); ?></a></h1>
                        <p><a href="../userPage/<?php echo e($drawing->artistId); ?>}"><?php echo e(__('messages.author')); ?>: <?php echo e(\App\User::find($drawing->artistId)->name); ?></a></p>
                        <p><?php echo e(__('messages.size')); ?>: <?php echo e($drawing->size); ?></p>
                        <h1 class="mt-md-5"><?php echo e(__('messages.price')); ?>: <?php echo e($drawing->price); ?>€</h1>
                    </div>
                </div>
                    <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php echo $drawings->appends(\Request::except('page'))->render(); ?>

    </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>