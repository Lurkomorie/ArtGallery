<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Send Mail</h1>
        <form action="send" method="post">
            <?php echo csrf_field(); ?>
            from: <input type="text" name="from">
            to: <input type="text" name="to">
            message: <textarea name="message" cols="20" rows="10"></textarea>
            <input type="submit" value="Send">
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>