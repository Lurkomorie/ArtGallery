<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header"><?php echo e(__('Update event')); ?></div>

                    <div class="card-body">
                        <form action="<?php echo e(route('update_event')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>

                            <div class="form-group row">
                                <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Name')); ?></label>

                                <div class="col-md-6">
                                    <input id="name" type="text" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e($event->name); ?>" required autofocus>

                                    <?php if($errors->has('name')): ?>
                                        <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="city" class="col-md-4 col-form-label text-md-right"><?php echo e(__('City')); ?></label>

                                <div class="col-md-6">
                                    <input id="city" type="text" class="form-control<?php echo e($errors->has('city') ? ' is-invalid' : ''); ?>" name="city" value="<?php echo e($event->city); ?>" required>

                                    <?php if($errors->has('city')): ?>
                                        <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('city')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="country" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Country')); ?></label>

                                <div class="col-md-6">
                                    <input id="country" type="text" class="form-control<?php echo e($errors->has('country') ? ' is-invalid' : ''); ?>" name="country" value="<?php echo e($event->country); ?>" required>

                                    <?php if($errors->has('country')): ?>
                                        <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('country')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="date" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Date')); ?></label>

                                <div class="col-md-6">
                                    <input id="date" type="date" class="form-control<?php echo e($errors->has('date') ? ' is-invalid' : ''); ?>" name="date" value="<?php echo e($event->date); ?>" required>

                                    <?php if($errors->has('date')): ?>
                                        <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('date')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="textarea" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Description')); ?></label>

                                <div class="col-md-6">
                                    <textarea id="description" type="text" rows="3" class="form-control<?php echo e($errors->has('description') ? ' is-invalid' : ''); ?>" name="description" value="<?php echo e($event->description); ?>" required></textarea>

                                    <?php if($errors->has('description')): ?>
                                        <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('description')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row mb-0">
                                <div class="col-md-6 offset-md-4">
                                    <button type="submit" class="btn btn-primary">
                                        <?php echo e(__('Update')); ?>

                                    </button>
                                </div>
                            </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>