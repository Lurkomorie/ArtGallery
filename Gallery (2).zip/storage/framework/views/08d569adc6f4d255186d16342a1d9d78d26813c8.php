<?php $__env->startSection('content'); ?>

    <div class="container">
            <nav class="navbar navbar-expand-md navbar-light navbar-laravel">
                <div class="container">
                    <form class="form-inline pull-xs-right" action="<?php echo e(route('find_artist')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <select id="column" name="column" class="form-group form-control mr-md-2">
                            <option value="name"><?php echo e(__('messages.name')); ?></option>
                            <option value="city"><?php echo e(__('messages.city')); ?></option>
                            <option value="country"><?php echo e(__('messages.country')); ?></option>
                        </select>

                        <div class="form-group">
                            <input id="search" type="text" class="form-control<?php echo e($errors->has('search') ? ' is-invalid' : ''); ?>" name="search" placeholder="<?php echo e(__('messages.search')); ?>" required autofocus>

                            <?php if($errors->has('search')): ?>
                                <span class="invalid-feedback">
                                <strong><?php echo e($errors->first('search')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>
                        <button type="submit" class="btn btn-outline-success ml-md-2">
                            <?php echo e(__('messages.search')); ?>

                        </button>
                    </form>
                </div>
            </nav>
        <div class="card-columns py-5 bg-light ml-4">

            <?php $__currentLoopData = $artists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $artist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(!$artist->deleted && $artist->activated): ?>
                <a href="userPage/<?php echo e($artist->id); ?>" style="text-decoration: none; color: black;">
                    <div class="card box-shadow ">
                        <img class="img-fluid rounded float-right mb-md-3" src="../<?php echo e($artist->avatar); ?>" alt="">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($artist->name); ?></h5>
                            <ul class="list-group list-group-flush">
                                <li class="list-group-item"><?php echo e(__('messages.country')); ?>: <?php echo e($artist->country); ?></li>
                                <li class="list-group-item"><?php echo e(__('messages.city')); ?>: <?php echo e($artist->city); ?></li>
                                <li class="list-group-item">BIO: <?php echo e($artist->bio); ?></li>
                            </ul>
                        </div>
                        <?php if(Auth::check()): ?>
                            <?php if(Auth::user()->id==$artist->id || Auth::user()->admin): ?>
                                <a type="button" href="../../updateUser/<?php echo e($artist->id); ?>"class="btn btn-secondary"><?php echo e(__('messages.edit')); ?></a>
                                <a type="button" href="../../removeUser/<?php echo e($artist->id); ?>"class="btn btn-secondary"><?php echo e(__('messages.delete')); ?></a>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>


                </a>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>