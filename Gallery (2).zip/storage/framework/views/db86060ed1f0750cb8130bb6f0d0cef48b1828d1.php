<?php $__env->startSection('content'); ?>

    <form action="<?php echo e(route('create_drawing')); ?>" method="post" enctype="multipart/form-data">
        <input name="_token" type="hidden" value="<?php echo e(csrf_token()); ?>">
        <label>
            Title
            <input name='name' type='text'>
        </label>
        <br>
        <label>
            Country
            <input name='country' type='text'>
        </label>
        <br>
        <label>
            City
            <input name='city' type='text'>
        </label>
        <br>
        <label>
            Date
            <input name='date' type='text'>
            Write in dd/mm/yyyy format
        </label>
        <br>
        <label>
            Genre
            <input name='genre' type='text'>
        </label>
        <br>
        <label>
            Technology
            <input name='technology' type='text'>
        </label>
        <br>
        <label>
            Size
            <input name='size' type='text'>
        </label>
        <br>
        <label>
            Status
            <select name="status">
                <option value="For Sale">For Sale</option>
                <option value="Sold">Sold</option>
                <option value="Not for Sale">Not for Sale</option>
                <option value="Private Collection">Private Collection</option>
                <option value="Donated">Donated</option>
            </select>
        </label>
        <br>
        <label>
            Price
            <input name="price" type="number">
        </label>
        <br>
        <label>
            <input type="file" name="image">
        </label>
        <br>
        <label>
            <input type="submit">
        </label>

    </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>