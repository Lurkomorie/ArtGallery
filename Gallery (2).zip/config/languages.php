<?php

return [
'en' => 'English',
'ru' => 'Russian',
];